import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ClientService } from '../client.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-client-edit-view-info',
  templateUrl: './client-edit-view-info.component.html',
  styleUrls: ['./client-edit-view-info.component.scss']
})
export class ClientEditViewInfoComponent implements OnInit {


  public customerID: number = 0;
  customerType: string = '';
  compName: string = '';
  postalCode: string = '';
  address1: string = '';
  address2: string = '';
  landmark: string = '';
  country: string = ''


  state: string = '';
  city: string = '';
  custPhone: string = ''
  custMobile: string = '';
  lang: string = '';
  custEmail: string = "";
  isEditable = false
  disabled = true;
  countryList = []
  stateList = []
  cityList = []
  PostalCodeList = []
  languageArray = []
  basicDetails: any = {}
  public custType = [{ name: 'Business', id: 'Business' }, { name: 'Individual', id: 'Individual' }]
  form: FormGroup = this.fb.group({
    customerType: [{ value: '', disabled: true }, Validators.required],
    name: ['', Validators.required],
    email: [{ value: '', disabled: true }],
    phone: [''],
    mobile: ['', Validators.required],
    language: [''],
    country: ['', Validators.required],
    state: ['', Validators.required],
    city: ['', Validators.required],
    postalCode: ['', Validators.required],
    address1: ['', Validators.required],
    address2: [''],
    landMark: ['']
  });

  constructor(private fb: FormBuilder, private service: ClientService, private snackBar: MatSnackBar,
    private router: Router, private route: ActivatedRoute,
  ) {

  }


  ngOnInit(): void {
    this.route.queryParams.subscribe(async params => {
      this.customerID = params['cid'];
      await this.getcountrylist()
      await this.getLanguagelist()
      this.getBasicDetails(this.customerID)

    });
  }
  async getBasicDetails(cid) {
    var countryId = 192

    var stateID = 2148
    var cityId = 164012
    this.service.getBasicDetails(cid)
      .subscribe({
        next: async (res: any) => {
          if (countryId > 0)
            await this.getStateList(countryId)

          if (stateID > 0) {
            await this.getCityList(stateID)
          }
          if (cityId > 0) {
            await this.getPostalCodeList(cityId)
          }
          
          this.basicDetails = res.data
          this.customerType = this.basicDetails.customerType;
          this.compName = this.basicDetails.name;
          this.postalCode = this.basicDetails.postalCode;
          this.address1 = this.basicDetails.address1;
          this.address2 = this.basicDetails.address2;
          this.landmark = this.basicDetails.landMark;
          this.country = this.basicDetails.country;
          this.state = this.basicDetails.state;
          this.city = this.basicDetails.city;
          this.custPhone = this.basicDetails.phone;
          this.custMobile = this.basicDetails.mobile;
          this.lang = this.basicDetails.language;
          this.custEmail = this.basicDetails.email;

          const formData = {
            customerType: this.basicDetails.customerType,
            name: this.basicDetails.name,
            postalCode: this.basicDetails.postalCode,
            address1: this.basicDetails.address1,
            address2: this.basicDetails.address2,
            landMark: this.basicDetails.landMark,
            // country: this.basicDetails.country,
            country: countryId,
            state: stateID,
            city: cityId,
            phone: this.basicDetails.phone,
            mobile: this.basicDetails.mobile,
            language: this.basicDetails.language,
            email: this.basicDetails.email

          }
          this.form.setValue(formData)
        }

      })
  }
  EditBasicDetails() {
    this.isEditable = true

  }
  cancel() {
    this.isEditable = false
  }
  async getcountrylist() {
    await this.service.getCountry()
      .subscribe({
        complete: () => { },
        error: (error) => {
          // this.showSnackbarTopPosition('Invalid email or password !!!','Error','2000') 
        },
        next: (resp: any) => {
          this.countryList = resp.data
        },     // nextHandler
      });

  }

  async getStateList(countryId) {
    await this.service.getState(countryId)
      .subscribe({
        complete: () => { },
        error: (error) => {
          // this.showSnackbarTopPosition('Invalid email or password !!!','Error','2000') 
        },
        next: (resp: any) => {
          this.stateList = resp.data
        },     // nextHandler
      });

  }

  async getCityList(stateId) {
    await this.service.getCity(stateId)
      .subscribe({
        complete: () => { },
        error: (error) => {
          // this.showSnackbarTopPosition('Invalid email or password !!!','Error','2000') 
        },
        next: (resp: any) => {
          this.cityList = resp.data
        },     // nextHandler
      });

  }

  async getPostalCodeList(cityId) {
    await this.service.getPostCode(cityId)
      .subscribe({
        complete: () => { },
        error: (error) => {
          // this.showSnackbarTopPosition('Invalid email or password !!!','Error','2000') 
        },
        next: (resp: any) => {
          this.PostalCodeList = [resp.data]
        },     // nextHandler
      });

  }
  async getLanguagelist() {
    await this.service.getLanguage().subscribe({
      next: (res: any) => {
        this.languageArray = res.data
      }
    })
  }

  onCountrySelect(event) {
    this.service.getState(event.value).subscribe({
      next: (res: any) => {
        this.stateList = res.data
      }
    })
  }

  stateSelect(event) {
    this.service.getCity(event.value.id).subscribe({
      next: (res: any) => {
        this.cityList = res.data
      }
    })
  }
}