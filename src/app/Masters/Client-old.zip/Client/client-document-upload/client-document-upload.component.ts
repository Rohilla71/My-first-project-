import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ClientService } from '../client.service';

export interface TableData {
  id: number;
  name: string;
  description: string;
  isActive: boolean;
  lastActionBy: string;
  lastActionOn: string;
}

@Component({
  selector: 'app-client-document-upload',
  templateUrl: './client-document-upload.component.html',
  styleUrls: ['./client-document-upload.component.scss']
})
export class ClientDocumentUploadComponent implements OnInit {
  fileName: string
  displayedColumns: string[] = ['fileName', 'fileDescription', 'filePath'];
  isLoading = true;
  dataList = []
  dataSource: MatTableDataSource<TableData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private service: ClientService, public dialog: MatDialog, private snackBar: MatSnackBar) {}

  ngOnInit() {
    //call api yo fetch file details in table
     this.getFileUploadDetails()
      }
    
      
      add(): void {
    
       
        // const dialogRef = this.dialog.open(CreateUnitListComponent, {
        //   width: '800px',
        //   disableClose: true
        // });
    
        // dialogRef.afterClosed().subscribe(resultJSON => {
        //   this.getUnitList();
        //   console.log('The dialog was closed');
        // });
      }
  
      getFileUploadDetails() {
        this.service.getFileUploadDetails().subscribe((p: any) => {
         // if (p.success == true) {
            this.isLoading = false;
            this.dataList = [
              {
                fileName: 'file.doc',
                fileDescription: 'File contains test data',
                filePath: 'https://picsum.photos/200/300'
              },
              {
                fileName: 'file2.doc',
                fileDescription: 'File contains test data 2',
                filePath: 'https://picsum.photos/200/300'
              }
            ]
            // this.dataList = p?.data;   need to revert when bind api
            this.bindTable(this.dataList);
         // }
        }),
          error => {
            this.isLoading = false;
            this.snackBar.open(error.message, 'Dismiss');
            console.log(error);
          }
    
      }
    
      bindTable(data: any) {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    
      //endregion
    
      ngAfterViewInit() {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    
      applyFilter(event: Event) {
        const filterValue = (event.target as HTMLInputElement).value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
    
        if (this.dataSource.paginator) {
          this.dataSource.paginator.firstPage();
        }
      }

      fileUpload(event) {
        const file:File = event.target.files[0];
          
        if (file) {
            this.fileName = file.name;
            const formData = new FormData();
            formData.append("thumbnail", file);
        }
      }

}
