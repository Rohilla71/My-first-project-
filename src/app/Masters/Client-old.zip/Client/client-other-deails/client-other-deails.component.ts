import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from '../client.service';
import { Editor } from 'ngx-editor';

@Component({
  selector: 'app-client-other-deails',
  templateUrl: './client-other-deails.component.html',
  styleUrls: ['./client-other-deails.component.scss']
})
export class ClientOtherDeailsComponent  implements OnInit {

  @Input() cid: number
  
  form: FormGroup
  reqfiletype = 'image/png'
  fileName: string;
  public currencyArray = []
  public languageArray = []
  public taxPreferenceArray = []
  public taxTreatmentArray = []
  editor: Editor;
  disclaimereditor: Editor;
  constructor(private fb: FormBuilder, private createCustomerService: ClientService ) {
    this.form = this.fb.group({
      dislayName: ['', Validators.required],
      currencyId: [''],
      taxTreatmentId: [''],
      panno: ['', Validators.required],
      accountNo:['', Validators.required],
      accountReference: ['', Validators.required],
      termsConditions: [''],
      disclaimer: [''],
      taxPreferenceId: ['', Validators.required]
    });
    this.getTaxTreatment()
    this.getCurrencylist()
    this.getTaxPref()
      
    
  }

  ngOnInit(): void {
    this.editor = new Editor();
    this.disclaimereditor=new Editor();
    this.otherDetailsTabData(this.cid)
  }


  otherDetailsTabData(customerId) {
    this.createCustomerService.getotherdetailstab(customerId).subscribe((list: any) => {
      this.form.setValue(list.data)
    },
      (error: any) => {
        throw error
      })
  }
  fileUpload(event) {
    const file:File = event.target.files[0];
      
    if (file) {
        this.fileName = file.name;
        const formData = new FormData();
        formData.append("thumbnail", file);
    }
  }

  SubmitForm() {
    // if (this.form.valid) {
    //     this.createCustomerService.createNewCustomer(this.form.value).subscribe(p => {
    //       if (p) {
    //         this.snackBar.open('Saved Successfully', 'Dismiss')
    //         this.close();
    //         this.router.navigate(['/other-details'])
    //       }
    //     }),
    //       error => {
    //         this.snackBar.open(error.message, 'Dismiss');
    //       }
    // }
    // else {
    //   this.form.markAllAsTouched();
    // }
  }
  
  Reset() {
    this.form.reset();
  }
  

  getTaxTreatment() {
    this.createCustomerService.getTaxTreatment().subscribe((list: any) => {
      this.taxTreatmentArray = list.data
    },
      (error: any) => {
        throw error
      })
  }
  
  getCurrencylist() {
    this.createCustomerService.getCurrency().subscribe((list: any) => {
      this.currencyArray = list.data
    },
      (error: any) => {
        throw error
      })
  }
  
  getTaxPref() {
    this.createCustomerService.getTaxPreference().subscribe((list: any) => {
      this.taxPreferenceArray = list.data
    },
      (error: any) => {
        throw error
      })
  }
}
