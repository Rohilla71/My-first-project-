import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ReplaySubject, catchError, throwError } from 'rxjs';
import { User } from 'src/app/Interfaces/User';
import { environment } from 'src/environments/environment';
import { ClientListResponse } from 'src/app/Interfaces/ClientList';

@Injectable({
  providedIn: 'root',
})
export class ClientService {

  baseUrl = environment.APiUrl;
  constructor(private http: HttpClient, private router: Router) {}

  getClients() {
    return this.http.get<ClientListResponse>(`${environment.APiUrl}Client/GetCustomerList`);
    // return this.http.get<ClientListResponse>("./assets/JSON/clientlist.json");
  }  

  createNewCustomer(form: any) {
    let data = {
      id: 0,
      customerType: form.customerType.value,
      name: form.companyName,
      email: form.customerEmail,
      phone: form.customerPhone,
      mobile: form.customerMobile,
      languageId: form.language.id,
      address1: form.address1 ,
      address2: form.address2,
      countryId: form.country.id,
      stateId: form.state.id,
      cityId: form.city.id,
      postalCodeId: form.postalCode,
      landmark: form.landmark
    }
    return this.http.post<any>(`${environment.APiUrl}Client/NewCustomer`, data).pipe(
      catchError(err => {
        console.log(err)
        return throwError(() => err)
      })
    )

   // return this.http.get('./assets/JSON/createcustomer.json')
  }

  getCountry() {
    return this.http.get(`${environment.APiUrl}Master/GetCountryList`)
  }
  getState(id) {
    return this.http.get(`${environment.APiUrl}Master/GetStateByCountryId/` +id  )
  }
  getCity(id) {
    return this.http.get(`${environment.APiUrl}Master/GetCityByStateId/` + id )
  }
  getPostCode(id) {
    return this.http.get(`${environment.APiUrl}Master/GetPostalCode/` + id )
  }
  getOtherDetails() {
    return this.http.get(`${environment.APiUrl}Master/GetCityByStateId/`)
  }
  getCurrency() {
    return this.http.get(`${environment.APiUrl}Master/GetCurrencyList`)
  }
  getTaxTreatment() {
    return this.http.get(`${environment.APiUrl}Master/GetCountryList`)
  }
  getTaxPreference() {
    return this.http.get(`${environment.APiUrl}Master/GetCountryList`)
  }
  getFileUploadDetails() {
    // return this.http.get(`${environment.APiUrl}/Master/GetCountryList`)
    return this.http.get('./assets/JSON/clientdocumentlist.json')
  }
  getLanguage() {
    return this.http.get(`${environment.APiUrl}Master/GetLanguageList`)
  }
  getBasicDetails(id) {
    return this.http.get(`${environment.APiUrl}Client/GetCustomer/` + id )
  }
  getotherdetailstab(id) {
    return this.http.get(`${environment.APiUrl}Client/GetOtherDetailsById?customerId=` + id)
  }

}
